-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 30, 2019 at 06:15 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE `anggota` (
  `id_anggota` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `kelas` varchar(5) NOT NULL,
  `no_tlp` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `anggota`
--

INSERT INTO `anggota` (`id_anggota`, `nama`, `nis`, `kelas`, `no_tlp`, `email`) VALUES
('001', 'Ali', '335', ' XI', '0867', 'alie@alie'),
('002', 'Nurman', '345', ' X', '0877', 'nurmanchoy'),
('003', 'Maruf', '355', ' XI', '0856', 'marufalie'),
('004', 'Deni', '376', ' XI', '0812', 'deni@purnama'),
('005', 'Hussein', '386', ' X', '0812', 'hussein@hussein.com'),
('006', 'Daniel', '386', ' XI', '087784380008', 'daniel@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `kategori_buku` varchar(30) NOT NULL,
  `kode_buku` varchar(50) NOT NULL,
  `judul_buku` varchar(50) NOT NULL,
  `pengarang` varchar(50) NOT NULL,
  `penerbit` varchar(50) NOT NULL,
  `tahun_terbit` varchar(5) NOT NULL,
  `edisi` varchar(5) NOT NULL,
  `isbn` varchar(50) NOT NULL,
  `jumlah` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`kategori_buku`, `kode_buku`, `judul_buku`, `pengarang`, `penerbit`, `tahun_terbit`, `edisi`, `isbn`, `jumlah`) VALUES
(' Umum', '001-001', 'Hidup Sederhana', 'Desi Anwar', 'Kepustakaan Populer Gramedia', '2014', '1', '9786020306209 ', 3),
(' Agama', '002-001', 'Jalan Hidup Abdul', 'Abdul', 'Gramedia', '2000', '2', '932748324', 0),
(' Sosial', '003-002', 'Sosial', 'Wendy', 'Gramedia', '2019', '1', '23456', 3),
(' Teknologi', '004-001', 'RxJava Android', 'GithubMaster', 'Github Inc', '2018', '1', '19238293928', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('admin', '12345'),
('user', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` varchar(5) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `id_anggota` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `kode_buku` varchar(50) NOT NULL,
  `judul_buku` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `tgl_pinjam`, `tgl_kembali`, `id_anggota`, `nama`, `kode_buku`, `judul_buku`) VALUES
('001', '2019-06-23', '2019-06-30', '001', 'Ali', '004-001', 'RxJava Android'),
('002', '2019-06-23', '2019-06-30', '001', 'Ali', '002-001', 'Jalan Hidup Abdul'),
('003', '2019-01-01', '2019-01-16', '001', 'Ali', '004-001', 'RxJava Android'),
('004', '2019-05-26', '2019-05-31', '001', 'Ali', '002-001', 'Jalan Hidup Abdul'),
('005', '2019-05-26', '2019-06-02', '001', 'Ali', '002-001', 'Jalan Hidup Abdul'),
('009', '2019-06-30', '2019-07-03', '001', 'Ali', '004-001', 'RxJava Android'),
('010', '2019-07-02', '2019-07-08', '006', 'Daniel', '001-001', 'Hidup Sederhana'),
('011', '2019-06-24', '2019-06-28', '001', 'Ali', '001-001', 'Hidup Sederhana');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`kode_buku`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
